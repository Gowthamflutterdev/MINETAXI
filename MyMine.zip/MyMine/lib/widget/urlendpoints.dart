const baseUrl = 'https://swaggerapi.nammaryduu.co.in/Gowtham';
const InsertUrl = '$baseUrl/insert_user.php';
const LoginUrl = '$baseUrl/login.php';
const driver_booking = '$baseUrl/driver_booking.php';
const driver_fetch = '$baseUrl/driver_fetch.php';
const UpdateUrl = '$baseUrl/driver_update.php';
const kGoogleApiKey = "AIzaSyAhijuLNm-rNYAq_We31fxQ5E7mao48Rys"; // Replace with your actual Google API key
